function whLog($str) {
    Write-Host -foregroundcolor 'Yellow' $str
}

function changePath{
    $qtPath = $packagerPath = $codePath = ""
    whLog "Please input the qt dir`nExample: C:\Qt\Qt{Version}\{Version}\mingw{Version}\bin"
    $qtPath = Read-Host
    whLog "Please input the innoSetup dir`nExample: F:\Program Files (x86)\Inno Setup{Version}"
    $packagerPath = Read-Host
    whLog "Please input the code dir"
    $codePath = Read-Host
    $codePath = $codePath + "/.."

    $qtPath = $qtPath + "/windeployqt.exe"
    $packagerPath = $packagerPath + "/ISCC.exe"

    $env:ndrBuildPath = $qtPath + ";" + $packagerPath + ";" + $codePath

    [environment]::SetEnvironmentvariable("ndrBuildPath", $env:ndrBuildPath, "User")
}

If (Test-Path env:ndrBuildPath){
    $workPath = $env:ndrBuildPath.split(";")
    $qtPath = $workPath[0]
    $packagerPath = $workPath[1]
    $codePath = $workPath[2]
} Else {
    whLog "Work PATH not found, initing now..."
    changePath
}

while (1){
    whLog "Build Release or Debug?[R/D](Using `"C`" to change env path)"
    $buildBranch = Read-Host
    If (($buildBranch -eq "C") -or ($buildBranch -eq "c")){
        Remove-Item env:ndrBuildPath
        changePath
        continue
    }
    break
}

whLog "Build Version?(null for no change)"
$version = Read-Host

Set-Location ./workSpace/source
Remove-Item -Recurse ./*
whLog "Build deploy..."

If (($buildBranch -eq "R") -or ($buildBranch -eq "r")){
    $file = "../ndrSetupForRelease.iss"
    $codePath = $codePath + "/build-ndr-client-Desktop_Qt_5_9_3_MinGW_32bit-Release/client/release"
} Else {
    $file = "../ndrSetupForDebug.iss"
    $codePath = $codePath + "/build-ndr-client-Desktop_Qt_5_9_3_MinGW_32bit-Debug/client/debug"
}


if ($version -ne ""){
    $setupContent = Get-Content -Encoding utf8 $file
    $setupContent = $setupContent -replace "#define MyAppVersion `"\d*\.\d*`"","#define MyAppVersion `"$version`""
    $setupContent = $setupContent -replace "OutputBaseFilename=ndr_setup_\d*\.\d*", "OutputBaseFilename=ndr_setup_$version"
    Out-File -Encoding utf8  -InputObject $setupContent -filepath $file
} Else {
    whLog "now"
}

Copy-Item $codePath/*.exe ./
& $qtPath --release ndr-client.exe
whLog "Packing..."
& $packagerPath /Q[q] $file

Set-Location ../..
whLog "Work Compile"